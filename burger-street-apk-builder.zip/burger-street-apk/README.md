# Burger Street APK Builder

This repo automatically builds an Android APK from your live PWA at:
**https://guileless-brioche-558e64.netlify.app/**

No PWA Builder needed. GitHub does the work for free in ~5-10 minutes.

---

## One-time Setup (do this once)

### Step 1 — Create a GitHub repo

1. Go to https://github.com/new
2. Name it `burger-street-apk` (or anything you like)
3. Set it to **Private**
4. Click **Create repository**

### Step 2 — Upload these files

Drag and drop this entire folder into the GitHub repo (or use Git).

### Step 3 — Add a secret for signing

1. In your GitHub repo, go to **Settings → Secrets and variables → Actions**
2. Click **New repository secret**
3. Name: `KEYSTORE_PASSWORD`
4. Value: any password you want (e.g. `BurgerStreet2026!`)
5. Click **Add secret**

### Step 4 — Run the workflow

1. Go to the **Actions** tab in your repo
2. Click **Build Burger Street APK**
3. Click **Run workflow → Run workflow**
4. Wait ~5-10 minutes ☕

### Step 5 — Download your APK

1. Once the workflow finishes (green checkmark ✅)
2. Click on the workflow run
3. Scroll down to **Artifacts**
4. Download **burger-street-apk**
5. Unzip it — your `.apk` file is inside!

---

## Installing the APK on Android

1. Send the `.apk` to your phone (WhatsApp, email, USB, Google Drive)
2. On your phone, open the file
3. If prompted, enable **"Install from unknown sources"** in settings
4. Tap Install

---

## Every time you update your app

Just push a change to the `main` branch — GitHub will automatically rebuild the APK.
Or go to Actions → Run workflow manually anytime.

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Workflow fails at "Initialize TWA project" | Make sure your Netlify URL is live and manifest.json is accessible |
| APK installs but shows blank screen | Check that your PWA works in Chrome on mobile first |
| "Install blocked" on phone | Enable unknown sources in Android Settings → Security |
